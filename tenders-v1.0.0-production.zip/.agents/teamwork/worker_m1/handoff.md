# RAPPORT DE HANDOFF — Worker M1 (Sécurité, Inscription & Récupération OTP WhatsApp)

**Date** : 2026-10-18T10:44:00Z  
**Auteur** : Worker M1 (`teamwork_preview_worker`)  
**Cible** : Orchestrator 1 (`ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9`)  
**Milestone** : M1 (Chantier R1 — Sécurité & OTP WhatsApp)  
**Chemin de travail** : `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m1`

---

## 1. OBSERVATIONS

### 1.1 Fichiers modifiés et créés
- `database.py` :
  - Lignes 16-17 : importation de `timedelta` et `timezone` depuis le module standard `datetime`.
  - Lignes 295-312 : ajout de la création de la table `password_reset_otps` et de ses index dans `_init_db()` :
    ```sql
    CREATE TABLE IF NOT EXISTS password_reset_otps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subscriber_id INTEGER NOT NULL,
        phone TEXT NOT NULL,
        otp_code TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        is_used INTEGER DEFAULT 0,
        created_at TEXT,
        FOREIGN KEY (subscriber_id) REFERENCES subscribers (id)
    );
    CREATE INDEX IF NOT EXISTS idx_reset_otps_sub ON password_reset_otps(subscriber_id);
    CREATE INDEX IF NOT EXISTS idx_reset_otps_phone ON password_reset_otps(phone);
    ```
  - Lignes 1054-1126 : implémentation de `create_password_reset_otp(self, phone: str)` et `verify_and_consume_password_reset_otp(self, phone: str, otp_code: str, new_password: str)`.
- `app.py` :
  - Lignes 204-213 : mise à jour de `http_exception_handler` pour inclure `"detail": exc.detail` en plus de `"error"`.
  - Lignes 438-458 : enrichissement de la réponse de souscription plan `TRIAL` pour retourner `success: True`, `plan: "TRIAL"`, et l'objet complet `subscriber`.
  - Lignes 627-686 : définition des modèles Pydantic `ForgotPasswordRequest`, `ForgotPasswordVerifyRequest`, et des routes FastAPI :
    - `POST /api/client/forgot-password/request`
    - `POST /api/client/forgot-password/verify`
- `templates/dashboard.html` et `public/dashboard.html` :
  - Section `#auth-section` refondue avec bascule d'onglets `[ Connexion ]` et `[ Créer un compte d'essai gratuit ]`.
  - Formulaire de connexion conservant l'œil de visibilité (👁️) et intégrant le bouton `"Mot de passe oublié ?"`.
  - Panneau de récupération WhatsApp étape par étape (Étape 1 : Saisie téléphone -> Étape 2 : Saisie OTP 6 chiffres + nouveau mot de passe avec œil).
  - Formulaire d'essai gratuit direct avec nom d'entreprise, téléphone WhatsApp, email, mot de passe avec œil, et cases à cocher de secteurs ciblés.
  - Fonctions JavaScript ajoutées : `switchAuthTab()`, `showForgotPassword()`, `resetForgotWorkflow()`, `handleRequestOtp()`, `handleVerifyOtp()`, `handleRegister()`.
- `test_m1_auth_otp.py` : suite de tests automatisés unitaire et d'intégration validant le milestone de bout en bout.

### 1.2 Exécution des tests et résultats
- Commande exécutée :
  ```powershell
  python -m unittest test_m1_auth_otp.py
  ```
- Sortie verbatim :
  ```
  Ran 8 tests in 4.266s
  OK
  ```
- Détail des 8 tests exécutés :
  1. `test_01_db_table_and_wal_mode` : PRAGMA journal_mode = `wal`, existence et colonnes de la table `password_reset_otps` vérifiées.
  2. `test_02_create_password_reset_otp` : génération de code cryptographique à 6 chiffres, support des numéros au format international et national (8 chiffres), rejet des numéros inexistants.
  3. `test_03_verify_and_consume_password_reset_otp` : validation de code, mise à jour PBKDF2 du mot de passe de l'abonné, vérification des identifiants et prévention de la réutilisation d'un code déjà consommé.
  4. `test_04_expired_otp_rejection` : simulation d'un code dont la date d'expiration (+10 min) est dépassée, vérification du rejet strict.
  5. `test_05_api_forgot_password_request_route` : appel HTTP 200 sur `/api/client/forgot-password/request`, expédition WhatsApp (Meta Cloud API réel vérifié avec message id `wamid`), test 404 sur numéro inconnu.
  6. `test_06_api_forgot_password_verify_route` : appel HTTP 200 sur `/api/client/forgot-password/verify`, connexion immédiate via `/api/client/login`, test code 400 sur code invalide.
  7. `test_07_api_subscribe_trial_onboarding` : inscription directe plan TRIAL via `POST /api/subscribe`, vérification du payload `subscriber`, authentification immédiate via `/api/client/login`.
  8. `test_08_template_mirror_synchronization` : parité binaire 100% entre `templates/dashboard.html` et `public/dashboard.html`, présence confirmée de l'ensemble des éléments DOM exigés.

---

## 2. LOGIC CHAIN

1. **Persistance des codes OTP dans SQLite** :
   - Conformément aux spécifications de `DISPATCH.md` et `PROJECT.md`, la table `password_reset_otps` a été créée avec les colonnes `(id, subscriber_id, phone, otp_code, expires_at, is_used, created_at)`.
   - L'utilisation du mode WAL (`PRAGMA journal_mode=WAL;`) garantit des accès concurrents sans risque de verrouillage entre les requêtes web et les processus en arrière-plan.

2. **Génération et consommation cryptographique de l'OTP** :
   - `create_password_reset_otp` utilise `secrets.randbelow(900000) + 100000` garantissant un entier aléatoire cryptographiquement sécurisé à 6 chiffres entre 100000 et 999999.
   - Les anciens codes non consommés pour le même abonné sont invalidés (`is_used = 1`) afin de garantir l'unicité de la fenêtre de validité.
   - La date d'expiration est fixée à `now + 10 minutes`.
   - `verify_and_consume_password_reset_otp` vérifie que le code existe, n'est pas utilisé, et que `now <= expires_at`.
   - Le mot de passe est ensuite haché à l'aide de l'algorithme standard PBKDF2-HMAC-SHA256 (100 000 itérations avec sel aléatoire de 16 octets) via `set_subscriber_password()`.

3. **Routes d'API FastAPI** :
   - `POST /api/client/forgot-password/request` extrait et normalise le numéro, crée l'OTP en base, transmet le message officiel via `send_whatsapp_message(sub.phone, msg)`, et retourne HTTP 200 avec `expires_in_minutes: 10`. Si le numéro n'est pas reconnu, il lève un code HTTP 404 (`Numéro de téléphone non associé à un compte Tenders.tn`).
   - `POST /api/client/forgot-password/verify` valide l'OTP, applique le nouveau mot de passe et retourne HTTP 200 (`Mot de passe réinitialisé avec succès`). Si l'OTP est faux ou expiré, il lève un code HTTP 400 (`Code OTP invalide ou expiré`).
   - `POST /api/subscribe` a été ajusté pour retourner directement l'objet `subscriber` lorsque `plan == "TRIAL"`, ce qui permet au client web d'initialiser immédiatement `localStorage.setItem('tenders_client_sub', ...)` sans friction.

4. **Synchronisation Frontend** :
   - Le système de rendu FastAPI priorisant `public/dashboard.html` avant `templates/dashboard.html`, la modification a été appliquée de manière rigoureusement identique aux deux fichiers.
   - `filecmp.cmp('templates/dashboard.html', 'public/dashboard.html', shallow=False)` a confirmé la parité absolue (`True`).

---

## 3. CAVEATS

- **Passerelle WhatsApp Meta Sandbox** : Lors des tests automatisés, pour des numéros de test aléatoires n'appartenant pas à la liste autorisée du compte développeur Meta (`Recipient phone number not in allowed list`), la passerelle bascule automatiquement sur Green-API puis sur le simulateur local sans bloquer la requête HTTP, comme prévu par l'architecture résiliente de `whatsapp_gateway.py`.
- **Aucune modification des autres modules** : Les fonctionnalités des autres chantiers (export Excel R2, pages légales R3, alertes enrichies R4) n'ont pas été touchées et restent prêtes pour leurs spécialistes respectifs.

---

## 4. CONCLUSION

Le Chantier R1 (Milestone M1) est **totalement achevé, fonctionnel et validé** :
- La table SQLite `password_reset_otps` et les méthodes associées sont en production avec hachage PBKDF2 préservé et mode WAL actif.
- Les endpoints `/api/client/forgot-password/request` et `/api/client/forgot-password/verify` répondent conformément aux contrats d'interface.
- L'interface du tableau de bord (`templates/dashboard.html` & `public/dashboard.html`) dispose des deux onglets fonctionnels, du flux modal de réinitialisation OTP WhatsApp, et de la création de compte d'essai immédiate.
- La suite de tests `test_m1_auth_otp.py` réussit à 100% (8/8 tests passés en 4,2s).

---

## 5. VERIFICATION METHOD

Pour vérifier de façon indépendante l'ensemble du travail de Worker M1 :

1. **Exécuter la suite de tests automatisés** :
   ```powershell
   python -m unittest test_m1_auth_otp.py
   ```
   *Résultat attendu* : `Ran 8 tests ... OK`.

2. **Vérifier la parité binaire des templates** :
   ```powershell
   python -c "import filecmp; print('Identical:', filecmp.cmp('templates/dashboard.html', 'public/dashboard.html', shallow=False))"
   ```
   *Résultat attendu* : `Identical: True`.

3. **Vérifier le mode SQLite WAL** :
   ```powershell
   python -c "import sqlite3; conn = sqlite3.connect('tenders.db'); print('journal_mode:', conn.execute('PRAGMA journal_mode;').fetchone()[0])"
   ```
   *Résultat attendu* : `journal_mode: wal`.

4. **Tester l'endpoint forgot-password par requête HTTP locale** :
   ```powershell
   python -c "from fastapi.testclient import TestClient; import app; client = TestClient(app.app); r = client.post('/api/client/forgot-password/request', json={'phone': '+21628177888'}); print(r.status_code, r.json())"
   ```
   *Résultat attendu* : `200 {'success': True, 'message': 'Code OTP expédié via WhatsApp', 'expires_in_minutes': 10}`.
