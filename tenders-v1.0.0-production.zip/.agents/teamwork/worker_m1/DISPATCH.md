# DISPATCH — Worker M1 (Sécurité, Inscription & Récupération OTP WhatsApp)

## Identity
- Archetype: teamwork_preview_worker
- Role: Security & Backend Worker
- Working directory: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m1
- Parent: orchestrator_1 (ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9)

## Context & Inputs
- Requirement source: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md (§R1)
- Project architecture & contracts: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md (§M1)
- Survey reports:
  - C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\explorer_survey_1\handoff.md
  - C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\explorer_survey_2\handoff.md
  - C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\explorer_survey_3\handoff.md

## Scope & Exclusive File Ownership
- `database.py` (table `password_reset_otps`, OTP creation and validation methods)
- `app.py` (endpoints `/api/client/forgot-password/request` and `/api/client/forgot-password/verify`)
- `templates/dashboard.html` & `public/dashboard.html` (section `#auth-section`: tab "Créer un compte d'essai", workflow "Mot de passe oublié ?")

## Implementation Requirements
1. **Database layer (`database.py`)**:
   - Create table `password_reset_otps` if not exists:
     `id INTEGER PRIMARY KEY, subscriber_id INTEGER, phone TEXT, otp_code TEXT, expires_at TEXT, is_used INTEGER DEFAULT 0, created_at TEXT`.
   - Method `create_password_reset_otp(phone: str) -> Tuple[Optional[Subscriber], Optional[str]]`:
     Lookup subscriber by phone (using existing phone normalization/lookup `get_subscriber_by_phone`), generate 6-digit cryptographic code (`f"{secrets.randbelow(900000) + 100000:06d}"`), store with expiration = `now + 10 minutes`, return subscriber and code.
   - Method `verify_and_consume_password_reset_otp(phone: str, otp_code: str, new_password: str) -> Tuple[bool, str]`:
     Validate code is active, not used, not expired. If valid, mark `is_used = 1`, hash `new_password` with `hash_password`, and update subscriber password via `set_subscriber_password(sub.id, new_password)`. Return `(True, "Success")`.
2. **API Routes (`app.py`)**:
   - `POST /api/client/forgot-password/request`:
     Request body `{"phone": "..."}`. Calls `create_password_reset_otp`. Sends WhatsApp message using `send_whatsapp_message(sub.phone, msg)`:
     `"🔐 Tenders.tn - Votre code de réinitialisation est : {otp_code}. Valable 10 minutes. Ne le partagez avec personne."`.
     Returns `{"success": true, "message": "Code OTP expédié via WhatsApp", "expires_in_minutes": 10}`.
     If phone not found, return 404 `{"detail": "Numéro de téléphone non associé à un compte Tenders.tn"}`.
   - `POST /api/client/forgot-password/verify`:
     Request body `{"phone": "...", "otp_code": "...", "new_password": "..."}`.
     Validates and updates password. Returns `{"success": true, "message": "Mot de passe réinitialisé avec succès"}`.
     If invalid or expired, return 400 `{"detail": "Code OTP invalide ou expiré"}`.
3. **Frontend UI (`templates/dashboard.html` AND `public/dashboard.html`)**:
   - Both files MUST remain 100% strictly synchronized.
   - In `#auth-section`:
     - Add clean tab bar toggle: `[ Connexion ]` and `[ Créer un compte d'essai gratuit ]`.
     - In Connexion tab: keep phone & password with toggle visibility 👁️, and add a link/button `"Mot de passe oublié ?"`.
     - Clicking "Mot de passe oublié ?" displays a recovery panel:
       * Step 1: Input phone + button "Envoyer le code WhatsApp" -> calls `/api/client/forgot-password/request`.
       * Step 2: Input 6-digit OTP + new password (with visibility toggle) + button "Valider et réinitialiser" -> calls `/api/client/forgot-password/verify`.
     - In "Créer un compte d'essai" tab: fields for company name, WhatsApp phone, email, password (with visibility toggle), sectors checkboxes. Submission calls `POST /api/subscribe` with `plan: "TRIAL"`, automatically logs in the client (`localStorage.setItem('tenders_client_sub', JSON.stringify(data.subscriber))`), and shows the dashboard immediately.
4. **Verification**:
   - Run unit/integration tests to verify OTP generation, WhatsApp dispatch, expiration, verification, and UI template parity.

## MANDATORY INTEGRITY WARNING
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.


## 2026-10-18T10:29:12Z
Received dispatch message:
"You are Worker M1 (Sécurité, Inscription & Récupération OTP WhatsApp).
Read your instructions in C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m1\DISPATCH.md.
Also read C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md and C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md.

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Implement:
1. `database.py`: `password_reset_otps` table, `create_password_reset_otp`, and `verify_and_consume_password_reset_otp`.
2. `app.py`: `/api/client/forgot-password/request` and `/api/client/forgot-password/verify`.
3. `templates/dashboard.html` AND `public/dashboard.html` (synchronously): tabs for "Créer un compte d'essai", workflow "Mot de passe oublié ?", preserve password visibility toggle.

Test your implementation thoroughly with automated tests.
Write your handoff report to C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m1\handoff.md.
Send a completion message to orchestrator_1 when finished."
