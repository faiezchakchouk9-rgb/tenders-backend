# Original User Request

## 2026-10-18T10:17:31Z

Équipe complète multi-agents répartie en parallèle entre spécialistes avec vérification croisée.

Implémenter et valider de bout en bout les 4 chantiers d'améliorations commerciales de la plateforme SaaS Tenders.tn afin de maximiser le taux de conversion, la conformité légale et la rétention client.

Working directory: `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie`
Integrity mode: development

## Requirements

### R1. Sécurité, Inscription & Récupération OTP WhatsApp
- Implémenter la procédure "Mot de passe oublié ?" : l'utilisateur saisit son numéro et reçoit par l'API WhatsApp officielle (Meta Cloud API / passerelle) un code OTP à 6 chiffres temporaire valable 10 minutes lui permettant de réinitialiser son mot de passe.
- Intégrer un onglet/bascule "Créer un compte d'essai gratuit" directement dans le modal d'authentification du dashboard afin de réduire les frictions d'onboarding.
- Conserver l'authentification par mot de passe chiffré PBKDF2 et la visibilité masquée/affichée.

### R2. Outils Métier, Export Excel & Filtrage Avancé
- Ajouter un endpoint et un bouton d'export direct au format Excel natif (.xlsx) et CSV dans l'onglet des opportunités, contenant l'ensemble des marchés correspondants au profil de l'entreprise (N° Avis, Acheteur, Objet, Région, Date limite, Cautionnement).
- Dans l'onglet "Mes Dossiers", implémenter une barre de filtrage instantané par statut (`TOUS`, `GENERE`, `DEPOSE_TUNEPS`, `RETENU`, `NON_RETENU`) sans rechargement de page.
- Ajouter une recherche instantanée par mot-clé et numéro d'avis dans l'onglet des opportunités.

### R3. Conformité Réglementaire & Juridique (Tunisie)
- Créer les pages professionnelles `/cgu` (Conditions Générales d'Utilisation) et `/confidentialite` (Politique de Confidentialité) conformes aux exigences des passerelles de paiement bancaires tunisiennes (Konnect, Flouci, GIM-TEL) et à la réglementation locale (Décret n° 2014-1039 et Loi organique n° 2004-63 relative à l'INPDP).
- Rendre ces pages accessibles via des liens clairs dans le pied de page du dashboard et de la landing page.

### R4. Alertes WhatsApp Interactives & Briefing Hebdomadaire
- Enrichir le formatage des messages d'alerte WhatsApp pour inclure des liens d'accès direct clairs (Fiche officielle TUNEPS, Dossier de soumission).
- Ajouter une tâche de briefing hebdomadaire du lundi matin (à 08h30) résumant les appels d'offres prioritaires de la semaine pour chaque abonné actif.

## Acceptance Criteria

### R1. Authentification & Récupération WhatsApp
- [ ] L'endpoint `/api/client/forgot-password/request` génère un OTP à 6 chiffres et l'expédie via WhatsApp.
- [ ] L'endpoint `/api/client/forgot-password/verify` valide le code et enregistre le nouveau mot de passe avec succès.
- [ ] Le formulaire de création de compte direct sur le dashboard permet à un nouvel utilisateur d'activer son essai et d'accéder immédiatement au tableau de bord.

### R2. Outils Métier & Export
- [ ] L'exportation Excel/CSV génère un fichier valide avec encodage UTF-8 et en-têtes corrects contenant la liste des marchés.
- [ ] Le filtre par statut dans "Mes Dossiers" filtre instantanément les cartes visibles selon le statut sélectionné.

### R3. Conformité Réglementaire
- [ ] Les routes `/cgu` et `/confidentialite` renvoient un statut HTTP 200 avec le contenu juridique tunisien complet et le design corporate de la plateforme.

### R4. Alertes WhatsApp
- [ ] Les alertes WhatsApp générées intègrent les liens directs formatés correctement.
- [ ] Le briefing du lundi est implémenté et testable via un endpoint de déclenchement d'essai.

### Intégrité & Synchronisation
- [ ] Toute modification apportée aux templates HTML est synchronisée entre `templates/` et `public/`.
- [ ] La base SQLite conserve le mode WAL et aucune régression n'est introduite sur l'authentification ni la génération des documents existants.
- [ ] Un script de test global vérifie le bon fonctionnement de l'ensemble des 4 modules.
