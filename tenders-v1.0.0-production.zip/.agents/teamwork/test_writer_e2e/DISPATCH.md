# DISPATCH — E2E Test Writer (Opaque-Box E2E Test Suite)

## Identity
- Archetype: teamwork_preview_test_writer
- Role: E2E Test Suite Engineer
- Working directory: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\test_writer_e2e
- Parent: orchestrator_1 (ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9)

## Context & Inputs
- Requirement source: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md
- Project architecture: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md

## Scope & File Ownership
- You own:
  1. `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\test_global_e2e.py`
  2. `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\TEST_READY.md`
- DO NOT modify any production source files (`app.py`, `database.py`, `notifier.py`, `templates/*`, `public/*`).

## Objectives & Methodology
Create an opaque-box, executable automated E2E test suite using Python `unittest` / `fastapi.testclient.TestClient` that covers all 4 requirements and integrity criteria:

1. **R1: Authentification & Récupération WhatsApp**:
   - `POST /api/client/forgot-password/request`: OTP 6 chiffres généré, validité 10 min, envoi WhatsApp.
   - `POST /api/client/forgot-password/verify`: validation OTP valide, rejet OTP invalide/expiré, hash PBKDF2 mis à jour.
   - Formulaire d'essai gratuit sur dashboard (`POST /api/subscribe` plan TRIAL) activant l'accès immédiat.
   - Préservation PBKDF2 et visibilité masquée/affichée.

2. **R2: Outils Métier & Export**:
   - `GET /api/client/opportunities/{sub_id}/export?format=xlsx` et `?format=csv` (avec UTF-8 / BOM `utf-8-sig`).
   - Présence des colonnes obligatoires: N° Avis, Acheteur, Objet, Région, Date limite, Cautionnement.
   - Filtrage instantané des opportunités (mot-clé et N° avis) et filtrage par statut dans "Mes Dossiers" (`TOUS`, `GENERE`, `DEPOSE_TUNEPS`, `RETENU`, `NON_RETENU`).

3. **R3: Conformité Réglementaire (Tunisie)**:
   - `GET /cgu` retourne HTTP 200 avec contenu juridique conforme (Décret 2014-1039, Konnect, Flouci, GIM-TEL).
   - `GET /confidentialite` retourne HTTP 200 avec contenu juridique conforme (Loi INPDP 2004-63).
   - Présence des liens dans les pieds de page (`index.html` et `dashboard.html`).

4. **R4: Alertes WhatsApp & Briefing**:
   - Alertes WhatsApp intégrant le lien officiel TUNEPS ET le lien direct vers le dossier de soumission Tenders.tn.
   - Briefing hebdomadaire du lundi 08h30 testable via `POST /api/client/weekly-briefing/{sub_id}`.
   - Absence d'erreur sur l'ordonnanceur d'arrière-plan.

5. **Intégrité & Synchronisation**:
   - Parité bit-à-bit stricte entre `templates/` et `public/` pour tous les templates HTML.
   - Préservation du mode SQLite WAL (`PRAGMA journal_mode=WAL;`).
   - Non-régression sur l'authentification existante et la génération des packs documentaires.

## Deliverables
1. `test_global_e2e.py`: Test suite autonome exécutable via `python test_global_e2e.py` ou `python -m unittest test_global_e2e.py`.
2. `TEST_READY.md` à la racine du projet, décrivant la commande de test, la couverture par tier et la checklist des fonctionnalités.
3. Handoff report dans votre répertoire de travail.


## 2026-10-18T10:29:12Z
Received dispatch message:
"You are the E2E Test Suite Engineer.
Read your instructions in C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\test_writer_e2e\DISPATCH.md.
Also read C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md and C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md.
Implement C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\test_global_e2e.py and C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\TEST_READY.md covering all 4 requirements (R1, R2, R3, R4) and integrity criteria using the 4-tier methodology.
DO NOT modify any production application files.
Run your test suite, document the results and write your handoff report to C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\test_writer_e2e\handoff.md.
Send a completion message when finished."
