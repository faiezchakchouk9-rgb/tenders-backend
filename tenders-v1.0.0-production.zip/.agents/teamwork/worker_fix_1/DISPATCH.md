# DISPATCH — Worker Fix 1 (Resolution of Reviewer 2 & Challenger 2 Findings)

## Identity
- Archetype: teamwork_preview_worker
- Role: Remediation & Polish Worker
- Working directory: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_fix_1
- Parent: orchestrator_1 (ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9)

## Context & Inputs
- Requirements: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md
- Reviewer 2 Report: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\reviewer_2\handoff.md
- Challenger 2 Report: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\challenger_2\handoff.md

## Scope & File Ownership
- `templates/dashboard.html` & `public/dashboard.html`
- `docx_generator.py`
- `test_global_e2e.py`

## Remediation Tasks

1. **Fix JavaScript Scoping Trap in `dashboard.html` (`templates/` and `public/`)**:
   - In `templates/dashboard.html`:
     - At line 1135 (end of `togglePasswordVisibility`), add the closing brace `}`.
     - At line 1329 (before `handleLogin`), remove the orphan closing brace `}`.
     - Verify that all 6 functions (`switchAuthTab`, `showForgotPassword`, `resetForgotWorkflow`, `handleRequestOtp`, `handleVerifyOtp`, `handleRegister`) are now top-level functions in the script block.
   - Synchronize bit-for-bit to `public/dashboard.html`.
   - Verify SHA256 checksum equality:
     `assert sha256(templates/dashboard.html) == sha256(public/dashboard.html)`

2. **Fix DOCX Page Dimensions in `docx_generator.py`**:
   - In `docx_generator.py:_create_single_page_document` around line 57:
     Add explicit ISO A4 dimensions for each section:
     ```python
     section.page_width = Inches(8.27)
     section.page_height = Inches(11.69)
     ```
   - Ensure dimensions match ISO A4 (210 x 297 mm) as required by Décret n° 2014-1039.

3. **Enhance Test Suite (`test_global_e2e.py`)**:
   - In `test_25_dashboard_frontend_ui_contracts`: Add an assertion verifying that in `templates/dashboard.html` and `public/dashboard.html`, `function switchAuthTab` is declared at top-level scope (nesting level 0) and not nested inside `togglePasswordVisibility`.
   - Add a test or assertion verifying that generated DOCX documents have `page_width` ~ 8.27 in and `page_height` ~ 11.69 in.

4. **Run Verification**:
   - Run `python test_global_e2e.py` (all 30+ tests must pass).
   - Run `python test_m1_auth_otp.py`.
   - Verify 100% binary template parity across all 9 HTML templates.
   - Write handoff report in your directory and report completion.

## MANDATORY INTEGRITY WARNING
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. An auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.


## 2026-10-18T11:25:33Z
You are Worker Fix 1 (Remediation & Polish Worker).
Read your instructions in C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_fix_1\DISPATCH.md.
Also read Reviewer 2 handoff report in C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\reviewer_2\handoff.md and Challenger 2 handoff report in C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\challenger_2\handoff.md.

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. An auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Tasks:
1. Fix the JavaScript scoping trap in templates/dashboard.html and public/dashboard.html: add closing brace to togglePasswordVisibility and remove orphan brace, ensuring switchAuthTab, showForgotPassword, resetForgotWorkflow, handleRequestOtp, handleVerifyOtp, handleRegister are top-level on window.
2. Ensure 100% bit-for-bit SHA256 parity between templates/dashboard.html and public/dashboard.html.
3. Fix docx_generator.py to explicitly set section.page_width = Inches(8.27) and section.page_height = Inches(11.69) for ISO A4 dimensions.
4. Enhance test_global_e2e.py to assert top-level function scope for auth functions in dashboard.html and A4 dimensions for docx.
5. Run python test_global_e2e.py and verify all tests pass.
Write your handoff report to C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_fix_1\handoff.md and notify orchestrator_1.
