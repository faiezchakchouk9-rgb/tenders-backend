# DISPATCH — Forensic Auditor (Integrity Forensics & Code Authenticity)

## Identity
- Archetype: teamwork_preview_auditor
- Role: Forensic Integrity Auditor
- Working directory: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\auditor_1
- Parent: orchestrator_1 (ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9)

## Context & Inputs
- Requirements: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md
- Project Scope: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md
- Test Suite: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\test_global_e2e.py

## Forensic Audit Scope
Perform an exhaustive, uncompromising integrity audit on all files touched across Milestones M1, M2, M3, M4:
1. **Static Analysis & Anti-Cheat**:
   - Verify that NO test results, expected outputs, or verification tokens are hardcoded inside `app.py`, `database.py`, `notifier.py`, `templates/*`, or `public/*`.
   - Verify that there are NO dummy or facade implementations that return mock data instead of real database / calculation queries.
   - Specifically check that `db.get_subscriber_matched_tenders` is genuinely queried in the export endpoints, that `password_reset_otps` actually persists and validates real cryptographic random codes via `secrets`, and that `send_weekly_briefing` actually formats and logs real notifications.
2. **Runtime Tracing & Execution Validation**:
   - Trace the flow of `/api/client/forgot-password/request` and `/verify`: ensure password hashing is genuine PBKDF2-HMAC-SHA256 (not plaintext or MD5/SHA1).
   - Trace `/api/client/opportunities/{sub_id}/export`: ensure actual OpenXML bytes are written via `openpyxl` and actual CSV lines are streamed with real tender data.
   - Trace `/cgu` and `/confidentialite`: ensure real legal content is served with HTTP 200, not blank pages or Lorem Ipsum.
   - Check template mirror synchronization: ensure `templates/` and `public/` are identical bit-for-bit and no divergence exists.
3. **Attestation & Verdict**:
   - Provide binary verdict: `CLEAN` or `INTEGRITY VIOLATION`.
   - If ANY cheating, shortcut, dummy facade, or hardcoded test artifact is detected, provide full evidence and issue an immediate `INTEGRITY VIOLATION`.
   - Document full evidence chain in `handoff.md`.

## 2026-10-18T11:14:57Z
From: orchestrator_1 (ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9)
Content:
You are the Forensic Integrity Auditor.
Read your instructions in C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\auditor_1\DISPATCH.md.
Also read C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md and PROJECT.md.
Perform a zero-tolerance forensic integrity audit across all modified code (database.py, app.py, notifier.py, templates/*, public/*).
Check for hardcoded tokens, fake mocks, dummy facades, test circumvention, genuine PBKDF2 hashing, genuine openpyxl XLSX generation, genuine CSV BOM encoding, and real legal text.
Write your handoff report with binary verdict (CLEAN or INTEGRITY VIOLATION) to C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\auditor_1\handoff.md and notify orchestrator_1.
