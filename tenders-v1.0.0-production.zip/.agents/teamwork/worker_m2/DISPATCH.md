# DISPATCH — Worker M2 (Outils Métier, Export Excel & Filtrage Avancé)

## Identity
- Archetype: teamwork_preview_worker
- Role: Business Tools & Export Worker
- Working directory: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m2
- Parent: orchestrator_1 (ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9)

## Context & Inputs
- Requirement source: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md (§R2)
- Project architecture & contracts: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md (§M2)
- Existing test suite: `test_global_e2e.py` (specifically `test_09_csv_utf8_bom_serialization`, `test_16_export_opportunities_csv_endpoint`, `test_17_export_opportunities_xlsx_endpoint`, `test_23_export_content_data_fidelity_and_encoding`, `test_25_dashboard_frontend_ui_contracts`).

## Scope & Exclusive File Ownership
- `requirements.txt` (add `openpyxl>=3.1.0,<4.0.0`)
- `app.py` (add endpoints `/api/client/opportunities/{sub_id}/export`, `/export.xlsx`, `/export.csv`)
- `templates/dashboard.html` & `public/dashboard.html` (add export buttons and instant search in tab opportunities; add filter pills bar in tab dossiers)

## Implementation Requirements

1. **Dependency Installation & Configuration (`requirements.txt`)**:
   - Add `openpyxl>=3.1.0,<4.0.0` to `requirements.txt`.
   - Install `openpyxl` in the environment (`pip install openpyxl`).

2. **Export Endpoints (`app.py`)**:
   - Create route `GET /api/client/opportunities/{sub_id}/export`:
     - Query parameter: `format: str = Query("xlsx", regex="^(xlsx|csv)$")`
     - Support also direct endpoints or aliases: `GET /api/client/opportunities/{sub_id}/export.xlsx` and `GET /api/client/opportunities/{sub_id}/export.csv`.
     - Validates subscriber exists (or return 404).
     - Fetches matched opportunities for the subscriber via `db.get_subscriber_matched_tenders(sub_id, limit=500)`.
     - Data columns (exact headers in French):
       `N° Avis`, `Acheteur`, `Objet`, `Région`, `Date limite`, `Cautionnement`, `Secteur`, `Lien TUNEPS`.
     - For CSV: Encodage UTF-8 avec BOM (`utf-8-sig`) afin d'ouvrir sans accroc dans Excel sous Windows avec accents et arabe. `Content-Type: text/csv; charset=utf-8`.
     - For XLSX: Workbook natif généré via `openpyxl` avec mise en forme propre (en-tête stylisé, colonnes ajustées). `Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`.
     - Header `Content-Disposition: attachment; filename="opportunites_tenders_tn_{sub_id}.{format}"`.

3. **Frontend UI (`templates/dashboard.html` AND `public/dashboard.html`)**:
   - Strict 1:1 mirror synchronization between both files.
   - **Onglet "Opportunités" (`#tab-opportunities`)**:
     - Au-dessus de la liste `#opportunities-list`, insérer une barre d'outils responsive contenant :
       1. Champ de recherche textuelle instantanée (`<input id="search-opportunities" placeholder="Rechercher par mot-clé, acheteur ou N° d'avis..." oninput="filterOpportunities()">`).
       2. Bouton "📥 Exporter Excel (.xlsx)" appelant `/api/client/opportunities/${currentSubscriber.id}/export?format=xlsx`.
       3. Bouton "📄 Exporter CSV" appelant `/api/client/opportunities/${currentSubscriber.id}/export?format=csv`.
     - Fonction JS `filterOpportunities()` filtrant en temps réel les cartes affichées à partir de `clientOpportunities` sans rechargement de page.
   - **Onglet "Mes Dossiers" (`#tab-dossiers`)**:
     - Au-dessus du conteneur `#dossiers-list-container`, insérer une barre de boutons filtres (pills) :
       `[ TOUS ]`, `[ GENERE ]`, `[ DEPOSE_TUNEPS ]`, `[ RETENU ]`, `[ NON_RETENU ]`.
     - Chaque bouton affiche le libellé et le compte dynamique si applicable.
     - Clic sur un bouton filtre instantanément les cartes visibles selon l'attribut de statut sans recharger la page.
     - Fonction JS `filterDossiersByStatus(status, btnElement)` gérant le filtrage client et la classe CSS active.

4. **Verification**:
   - Execute tests: verify that `test_16_export_opportunities_csv_endpoint`, `test_17_export_opportunities_xlsx_endpoint`, `test_23_export_content_data_fidelity_and_encoding`, and relevant parts of `test_25_dashboard_frontend_ui_contracts` now PASS in `python test_global_e2e.py`.
   - Verify `templates/` and `public/` binary parity.

## MANDATORY INTEGRITY WARNING
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. An auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

## 2026-10-18T10:43:32Z
[Message] sender=ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9 priority=MESSAGE_PRIORITY_HIGH
You are Worker M2 (Outils Métier, Export Excel & Filtrage Avancé).
Read your instructions in C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m2\DISPATCH.md.
Also read C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md and C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md.

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. An auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Implement:
1. `requirements.txt`: add `openpyxl>=3.1.0,<4.0.0` and install `openpyxl`.
2. `app.py`: `/api/client/opportunities/{sub_id}/export` supporting `format=xlsx` (native openpyxl) and `format=csv` (UTF-8 BOM utf-8-sig), with required headers (N° Avis, Acheteur, Objet, Région, Date limite, Cautionnement, Secteur, Lien TUNEPS).
3. `templates/dashboard.html` AND `public/dashboard.html` (synchronously):
   - In tab opportunities: instant search bar & export buttons (Excel and CSV).
   - In tab dossiers: instant status filter pills bar (TOUS, GENERE, DEPOSE_TUNEPS, RETENU, NON_RETENU).
4. Run tests, verify template parity, write handoff report to C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m2\handoff.md and notify orchestrator_1.
