# Plan d'Exécution: Plateforme Tenders.tn — 4 Chantiers Commerciaux

## Objectif
Implémenter et valider de bout en bout avec vérification croisée :
1. R1. Sécurité, Inscription & Récupération OTP WhatsApp
2. R2. Outils Métier, Export Excel & Filtrage Avancé
3. R3. Conformité Réglementaire & Juridique (Tunisie) (/cgu, /confidentialite)
4. R4. Alertes WhatsApp Interactives & Briefing Hebdomadaire
5. Intégrité, Synchronisation HTML (templates/ <-> public/) et Non-régression SQLite WAL

## Phases
- **Phase 0 : Exploration & Cartographie Initiale (Parallel Survey)**
  - Explorer 1 : Cartographie architecture backend (Python/Node/FastAPI/Flask/Express/SQLite), modèle de données, WAL, auth PBKDF2, endpoints existants.
  - Explorer 2 : Cartographie frontend, templates HTML (`templates/`, `public/`), modals d'auth, onglet opportunités, onglet mes dossiers, pied de page.
  - Explorer 3 : Cartographie WhatsApp (API Meta Cloud / passerelle / mock existant), cron/tâches planifiées existantes, export Excel existant ou librairies disponibles.
- **Phase 1 : Synthèse & PROJECT.md**
  - Fusion des rapports, confirmation des contrats d'interface, architecture, inventaire exhaustif des fonctionnalités.
- **Phase 2 : Déploiement Parallèle & Dual-Track**
  - Track Test E2E : Test Writer / E2E Suite autonome couvrant R1, R2, R3, R4, synchronisation HTML et intégrité SQLite.
  - Track Implémentation R1 : Workers spécialisés auth & WhatsApp OTP.
  - Track Implémentation R2 : Workers spécialisés export Excel/CSV & filtres/recherche instantanée.
  - Track Implémentation R3 : Workers spécialisés conformité juridique tunisienne & templates /cgu, /confidentialite.
  - Track Implémentation R4 : Workers spécialisés alertes enrichies & briefing hebdo du lundi.
- **Phase 3 : Revue Croisée, Adversarial Challenge & Audit Forensique**
  - Reviewers indépendants pour valider conformité et non-régression.
  - Challengers pour tester cas limites (OTP expiré, mauvais format, filtres dossiers, encodage UTF-8 Excel, WAL concurrency).
  - Forensic Auditor pour vérifier l'authenticité stricte des implémentations (aucune triche / mock en dur).
- **Phase 4 : Validation Globale E2E & Rapport Final au Sentinel**
  - Exécution du script de test global vérifiant tous les modules.
  - Rapport final détaillé au Sentinel.
