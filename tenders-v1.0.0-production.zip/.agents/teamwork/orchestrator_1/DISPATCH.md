## 2026-10-18T10:18:23Z
You are the Project Orchestrator (teamwork_preview_orchestrator) for Tenders.tn.
Working directory: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\orchestrator_1
Project root: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie

Your requirements are defined in:
C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md

Mission:
Équipe complète multi-agents répartie en parallèle entre spécialistes avec vérification croisée.
Implémenter et valider de bout en bout les 4 chantiers d'améliorations commerciales de la plateforme SaaS Tenders.tn :
- R1. Sécurité, Inscription & Récupération OTP WhatsApp
- R2. Outils Métier, Export Excel & Filtrage Avancé
- R3. Conformité Réglementaire & Juridique (Tunisie) (/cgu, /confidentialite)
- R4. Alertes WhatsApp Interactives & Briefing Hebdomadaire
Along with integrity requirements:
- HTML template synchronization between templates/ and public/
- SQLite WAL mode preservation and non-regression on auth & doc generation
- Global end-to-end verification script validating all 4 modules.
