import re, json

with open('templates/dashboard.html', encoding='utf-8') as f:
    lines = f.readlines()

print(f"Total lines: {len(lines)}")

results = []
for i, line in enumerate(lines):
    l_lower = line.lower()
    for kw in ['id="', 'switchtab', '<footer', 'cgu', 'confidentialite', 'forgot', 'auth-section', 'auth-modal', 'password-toggle', 'dossier']:
        if kw in l_lower:
            results.append({
                "line": i + 1,
                "text": line.strip()
            })
            break

with open('.agents/teamwork/explorer_survey_2/dashboard_structure.json', 'w', encoding='utf-8') as out:
    json.dump({"total_lines": len(lines), "matches": results}, out, indent=2, ensure_ascii=False)

print(f"Wrote {len(results)} matches to dashboard_structure.json")
