# RAPPORT DE HANDOFF — Explorer Survey 2 (Frontend, Templates Sync & UI Components)

**Date** : 2026-10-18T10:26:00Z  
**Auteur** : Explorer Survey 2 (`teamwork_preview_explorer`)  
**Cible** : Orchestrator 1 (`ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9`)  
**Projet** : Plateforme Tenders.tn (`C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie`)  

---

## 1. OBSERVATIONS

### 1.1. Structure des Répertoires Templates vs Public & Mécanisme de Distribution
- Deux répertoires de templates coexistent à la racine du projet :
  - `templates/` (7 fichiers : `admin.html`, `dashboard.html`, `index.html`, `print_clarification.html`, `print_commercial.html`, `print_proposal.html`, `print_tender.html`)
  - `public/` (7 fichiers avec les mêmes noms et tailles identiques)
- Commande de vérification de parité :
  ```python
  # Résultat de filecmp.cmp(templates/<f>, public/<f>):
  admin.html: identical=True
  dashboard.html: identical=True
  index.html: identical=True
  print_clarification.html: identical=True
  print_commercial.html: identical=True
  print_proposal.html: identical=True
  print_tender.html: identical=True
  ```
- **Règles de service dans `app.py`** :
  - Route `/` (lignes 540-549) :
    ```python
    pub_path = os.path.join(os.path.dirname(__file__), "public", "index.html")
    if os.path.exists(pub_path):
        with open(pub_path, "r", encoding="utf-8") as f:
            return f.read()
    template_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
    with open(template_path, "r", encoding="utf-8") as f:
        return f.read()
    ```
  - Route `/dashboard` & `/client` (lignes 754-765) :
    ```python
    pub_path = os.path.join(os.path.dirname(__file__), "public", "dashboard.html")
    if os.path.exists(pub_path):
        with open(pub_path, "r", encoding="utf-8") as f:
            return f.read()
    tmpl_path = os.path.join(os.path.dirname(__file__), "templates", "dashboard.html")
    ```
  - Route `/admin` (lignes 2441-2451) : même logique de priorité pour `public/admin.html` avant `templates/admin.html`.
  - Routes d'impression Jinja2 (`/tender/{tender_id}/proposal-print`, `/tender/{tender_id}/commercial-print`, `/tender/{tender_id}/clarification-print`, `/tender/{tender_id}/print`) : chargent directement depuis `templates/print_*.html`.
  - Configuration `firebase.json` (lignes 2-8) :
    ```json
    "hosting": {
      "public": "public",
      "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
      "rewrites": [{"source": "**", "destination": "/index.html"}]
    }
    ```
  - **Constat critique** : Dans `app.py`, `public/` a la priorité sur `templates/` pour toutes les pages principales. Si un développeur modifie uniquement un fichier dans `templates/`, le serveur continuera de renvoyer le fichier non modifié depuis `public/`. Toute modification de template HTML **doit être impérativement dupliquée à l'identique dans `public/`**.

---

### 1.2. État du Modal / Bloc d'Authentification (`templates/dashboard.html` & `public/dashboard.html`)
- L'authentification n'est pas un pop-up modal flottant, mais une section pleine page `<section id="auth-section" class="max-w-md mx-auto my-12 hidden">` (lignes 57-116).
- Elle est affichée lorsque `currentSubscriber` est nul (`showAuth()`, lignes 720-724) et masquée au profit de `#dashboard-section` (`showDashboard()`, lignes 726-786).
- **Contenu actuel du bloc d'authentification** :
  - Titre : `Mon Espace Client Privé`
  - Un formulaire unique `<form id="login-form">` (lignes 68-114).
  - Champ numéro WhatsApp (`#login-phone`).
  - Champ mot de passe (`#login-password`) avec bascule de visibilité fonctionnelle :
    ```html
    <button type="button" onclick="togglePasswordVisibility('login-password', this)" title="Afficher/Masquer le mot de passe">👁️</button>
    ```
    Code JS (lignes 788-798) : alterne entre `type="password"` (👁️) et `type="text"` (🔒).
  - Soumission gérée par `handleLogin(e)` (lignes 800-834) appelant `POST /api/client/login`.
- **Éléments absents (Exigences R1)** :
  1. Aucun onglet ou bascule "Créer un compte d'essai gratuit" (l'utilisateur doit retourner sur la landing page `/` pour souscrire).
  2. Aucun lien "Mot de passe oublié ?".
  3. Aucun formulaire ou étape de saisie OTP / réinitialisation de mot de passe WhatsApp.

---

### 1.3. Onglet "Opportunités Ciblées" (`#tab-opportunities`)
- Définition HTML (lignes 243-262 de `dashboard.html`) :
  - Conteneur `<div id="tab-opportunities" class="tab-pane space-y-4">`.
  - En-tête : Titre "Appels d'offres TUNEPS pour votre profil" + bouton "Actualiser" (`onclick="loadOpportunities()"`).
  - Grille d'affichage : `<div id="opportunities-list" class="grid grid-cols-1 md:grid-cols-2 gap-4">`.
- Logique JS (`loadOpportunities()` et `renderOpportunities()`, lignes 859-940) :
  - Requête `GET /api/client/opportunities/${currentSubscriber.id}`.
  - Stockage dans la variable globale `clientOpportunities`.
  - Rendu direct en cartes de 2 colonnes avec métadonnées : badge secteur, compte à rebours, acheteur, région, caution, évaluation, N° Avis, synthèse IA, actions (Pack ZIP, Mémoire, Offre commerciale, Imprimer).
- **Éléments absents (Exigences R2)** :
  1. Aucune barre de recherche instantanée par mot-clé et numéro d'avis.
  2. Aucun bouton d'export direct natif Excel (`.xlsx`).
  3. Aucun bouton d'export direct CSV (`.csv`).

---

### 1.4. Onglet "Mes Dossiers Déposés" (`#tab-dossiers`)
- Définition HTML (lignes 452-473 de `dashboard.html`) :
  - Conteneur `<div id="tab-dossiers" class="tab-pane space-y-4 hidden">`.
  - En-tête : Titre "Historique de vos Dossiers & Soumissions TUNEPS" + bouton "Actualiser" (`onclick="loadSubscriberDossiers()"`).
  - Liste : `<div id="dossiers-list-container" class="space-y-3">`.
- Logique JS (`loadSubscriberDossiers()`, lignes 2729-2823) :
  - Requête `GET /api/client/dossiers/${currentSubscriber.id}`.
  - Rendu de chaque dossier sous forme de carte horizontale avec :
    - Badge N° Avis TUNEPS.
    - Badge Statut juridique (`dossierStatus` = `GENERE`, `DEPOSE_TUNEPS`, `RETENU`, `NON_RETENU`).
    - Métadonnées (acheteur, date limite, date de génération, nombre de pièces).
    - Sélecteur de mise à jour `<select onchange="updateDossierStatus(${d.id}, this.value)">`.
    - Bouton "Re-télécharger" (`downloadSubmissionPack`) et bouton Calendrier (`syncToCalendar`).
- **Éléments absents (Exigences R2)** :
  1. Aucune barre de filtrage instantané par statut (`TOUS`, `GENERE`, `DEPOSE_TUNEPS`, `RETENU`, `NON_RETENU`).
  2. Actuellement, la totalité des dossiers est rendue sans possibilité de filtrage direct côté client.

---

### 1.5. Pieds de Page (Footers) & Conformité Juridique
- **Pied de page de la Landing Page (`index.html`)** :
  - Lignes 320-324 :
    ```html
    <footer class="border-t border-slate-800/80 py-8 text-center text-xs text-slate-500">
        <p>© 2026 Tenders.tn — Service indépendant d'agrégation et d'alerte sur les marchés publics tunisiens (TUNEPS).</p>
        <p class="mt-1">Paiements sécurisés par passerelles agréées Banque Centrale de Tunisie (Konnect / GIM-TEL).</p>
    </footer>
    ```
  - **Constat** : Aucun lien vers `/cgu` ni `/confidentialite`.
- **Pied de page du Dashboard (`dashboard.html`)** :
  - Lignes 670-676 : le tag `<main>` se ferme immédiatement suivi de la balise `<script>`.
  - **Constat** : **Aucun footer n'existe dans `dashboard.html`**.
- **Pages juridiques (`/cgu` et `/confidentialite`)** :
  - Aucune route `@app.get("/cgu")` ni `@app.get("/confidentialite")` n'existe dans `app.py`.
  - Aucun fichier `cgu.html` ni `confidentialite.html` n'existe dans `templates/` ni dans `public/`.

---

### 1.6. Assets, Stylesheets et Bibliothèques Client
- **CSS** : Intégralement géré par le CDN Tailwind v3 (`<script src="https://cdn.tailwindcss.com"></script>`). Aucun fichier `.css` local.
- **Polices** : Google Fonts `Inter` (`https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap`).
- **Icônes** : Emojis Unicode natifs (📱, 🔑, 👁️, 🔒, 🎯, 📁, 🏛️, ⚙️, etc.). Aucun bundle d'icônes lourd (FontAwesome, Lucide).
- **Scripts JS** : Aucun script externe ou bundle JS local ; toute la logique est inline dans la balise `<script>` de chaque page HTML.
- **Dépendance Python manquante pour l'export Excel natif** :
  - L'environnement virtuel ne possède pas `openpyxl` (`ModuleNotFoundError: No module named 'openpyxl'`). Le module d'implémentation devra soit installer `openpyxl`, soit générer un fichier XML Spreadsheet / CSV natif propre.

---

## 2. LOGIC CHAIN

```
[Observation 1.1: app.py lit en priorité dans public/*.html avant templates/*.html]
         │
         ▼
[Étape 1: Risque de désynchronisation critique]
Toute modification apportée dans templates/ doit être répliquée rigoureusement dans public/.
Sinon, l'utilisateur verra l'ancienne version en production et en local.

[Observation 1.2: Le bloc d'authentification est un formulaire simple sans onglets ni mot de passe oublié]
         │
         ▼
[Étape 2: Conception de l'Auth Modal multi-mode (R1)]
1. Ajouter un switch d'onglets au sommet de #auth-section :
   - Onglet 1 : "Connexion" (formulaire existant conservé)
   - Onglet 2 : "Essai Gratuit 7 Jours" (nom entreprise, téléphone WhatsApp, email, mot de passe avec œil, secteurs d'activité, gouvernorats).
2. Ajouter sous le mot de passe de connexion un lien "Mot de passe oublié ?".
3. Intégrer un sous-panneau réversible en 2 temps pour l'OTP WhatsApp :
   - Étape A : Saisie du numéro WhatsApp -> Bouton "Recevoir le code par WhatsApp" (appelle /api/client/forgot-password/request).
   - Étape B : Saisie de l'OTP 6 chiffres + nouveau mot de passe + confirmation -> Bouton "Valider et réinitialiser" (appelle /api/client/forgot-password/verify).

[Observation 1.3: L'onglet Opportunités dispose des données clientOpportunities mais aucun filtre ni export]
         │
         ▼
[Étape 3: Conception de la Toolbar Opportunités (R2)]
1. Insérer au-dessus de #opportunities-list une barre d'action responsive :
   - Un champ de recherche textuelle avec écouteur oninput="filterOpportunities()" pour filtrer instantanément par t.bid_no ou t.title_fr/buyer_name.
   - Deux boutons d'exportation :
     * Bouton "📥 Export Excel (.xlsx)"
     * Bouton "📄 Export CSV"
2. Connecter les exports à l'endpoint dédié de téléchargement (contenant N° Avis, Acheteur, Objet, Région, Date limite, Cautionnement).

[Observation 1.4: L'onglet Mes Dossiers liste tous les dossiers sans filtre]
         │
         ▼
[Étape 4: Conception de la Barre de Filtres Statut Dossiers (R2)]
1. Insérer au-dessus de #dossiers-list-container une barre de filtres (boutons pills) :
   [ TOUS (N) ] [ GÉNÉRÉ (N) ] [ DÉPOSÉ TUNEPS (N) ] [ RETENU (N) ] [ NON RETENU (N) ]
2. Côté JS, sauvegarder la liste complète `allSubscriberDossiers` et filtrer instantanément sans requête réseau supplémentaire.

[Observation 1.5: Absence totale de pages CGU / Confidentialité et de liens footer]
         │
         ▼
[Étape 5: Conformité Légale & Navigation Footer (R3)]
1. Créer templates/cgu.html et public/cgu.html (conditions d'utilisation conformes Konnect/Flouci/GIM-TEL et Décret 2014-1039).
2. Créer templates/confidentialite.html et public/confidentialite.html (politique conforme Loi INPDP n° 2004-63 et WhatsApp Cloud).
3. Déclarer les routes FastAPI correspondantes dans app.py.
4. Mettre à jour le footer de index.html avec les liens vers /cgu et /confidentialite.
5. Créer et injecter le composant <footer> dans dashboard.html.
```

---

## 3. CAVEATS

1. **Environnement Python & Export Excel** : `openpyxl` n'est pas préinstallé dans l'environnement local (`pip list` ne le contient pas). L'implémenteur de R2 devra ajouter `openpyxl` dans `requirements.txt` ou utiliser une alternative sans dépendance externe (CSV UTF-8 avec BOM `\ufeff` pour compatibilité native Excel).
2. **Zone d'impact template** : Aucune modification de code source n'a été effectuée durant cette phase exploratoire conformément aux règles de l'archétype Explorer.
3. **Persistance locale** : Le dashboard s'appuie sur `localStorage.getItem('tenders_client_sub')`. Lors de l'inscription directe "Essai Gratuit", le client devra être connecté automatiquement en écrivant cet objet dans le `localStorage` dès réception de la réponse serveur.

---

## 4. CONCLUSION

L'analyse de l'architecture frontend est complète. Les interventions UI sont parfaitement délimitées et ne présentent aucun blocage structurel :
- **R1** : Modification du bloc `<section id="auth-section">` dans `templates/dashboard.html` et `public/dashboard.html` pour supporter les 2 onglets (Connexion / Essai gratuit) et le flux modal OTP WhatsApp (Demande OTP -> Saisie code 6 chiffres -> Nouveau mot de passe).
- **R2** : Ajout d'une barre de recherche instantanée mot-clé / N° Avis et des 2 boutons d'export (Excel / CSV) dans `#tab-opportunities` ; ajout d'une barre de pills de filtrage par statut (`TOUS`, `GENERE`, `DEPOSE_TUNEPS`, `RETENU`, `NON_RETENU`) dans `#tab-dossiers`.
- **R3** : Création des deux templates `cgu.html` et `confidentialite.html` (synchronisés dans `templates/` et `public/`), ajout des routes correspondantes dans `app.py`, et intégration des liens dans les footers de `index.html` et `dashboard.html`.
- **Intégrité de synchronisation** : Toute modification apportée aux templates doit systématiquement être appliquée aux deux répertoires miroirs `templates/` et `public/`.

---

## 5. VERIFICATION METHOD

Pour vérifier indépendamment ces constats et valider les futures implémentations :

1. **Vérification de la parité templates/ vs public/** :
   ```bash
   python -c "import filecmp, os; files=['admin.html','dashboard.html','index.html','print_clarification.html','print_commercial.html','print_proposal.html','print_tender.html']; print(all(filecmp.cmp(os.path.join('templates', f), os.path.join('public', f), shallow=False) for f in files))"
   ```
   *Résultat attendu* : `True`.

2. **Vérification de l'absence actuelle des routes juridiques** :
   ```bash
   python -c "with open('app.py', encoding='utf-8') as f: c = f.read(); print('/cgu' in c, '/confidentialite' in c)"
   ```
   *Résultat attendu* : `False False` (devra devenir `True True` après implémentation).

3. **Vérification de la présence de l'œil de mot de passe existant** :
   ```bash
   python -c "with open('templates/dashboard.html', encoding='utf-8') as f: print('togglePasswordVisibility' in f.read())"
   ```
   *Résultat attendu* : `True`.

4. **Test de démarrage du serveur FastAPI** :
   ```bash
   python -m uvicorn app:app --port 8000
   ```
   Puis inspecter `http://localhost:8000/`, `http://localhost:8000/dashboard`, `http://localhost:8000/cgu` et `http://localhost:8000/confidentialite`.
