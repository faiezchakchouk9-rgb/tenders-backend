# DISPATCH — Worker M4 (Alertes WhatsApp Enrichies & Briefing Hebdomadaire)

## Identity
- Archetype: teamwork_preview_worker
- Role: WhatsApp & Scheduler Worker
- Working directory: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m4
- Parent: orchestrator_1 (ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9)

## Context & Inputs
- Requirement source: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md (§R4)
- Project architecture & contracts: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md (§M4)
- Existing tests: `test_08_whatsapp_alert_enrichment_format`, `test_10_scheduler_method_integrity`, `test_20_weekly_briefing_client_endpoint`, `test_21_weekly_briefing_admin_endpoint` in `test_global_e2e.py`.

## Scope & File Ownership
- `notifier.py` (enrich `format_whatsapp_message`, implement `send_weekly_briefing`)
- `app.py` (fix scheduler bug at line 88, add Monday 08h30 trigger in `autonomous_scheduler_loop`, add routes `POST /api/client/weekly-briefing/{sub_id}` and `POST /api/admin/dispatch-weekly-briefing`)

## Implementation Requirements
1. **WhatsApp Alert Formatting (`notifier.py:format_whatsapp_message`)**:
   - Enrich the message template to include explicit, clearly formatted direct links:
     - Fiche officielle TUNEPS : `🔗 *Fiche officielle TUNEPS :* {tender.url}`
     - Dossier de soumission Tenders.tn : `📂 *Dossier de soumission Tenders.tn :* {app_url}/dashboard?tab=dossiers&tender={bid_id}`
   - Ensure the string "Dossier de soumission" and the parameter `tab=dossiers` are present in all formatted alert messages.
2. **Weekly Briefing Logic (`notifier.py`)**:
   - Implement method `send_weekly_briefing(self, subscriber_id: Optional[int] = None) -> Dict[str, Any]`:
     - If `subscriber_id` is specified, process that active subscriber; otherwise iterate over all active subscribers (`db.get_active_subscribers()`).
     - Query matched tenders non expired for the subscriber (`db.get_subscriber_matched_tenders(sub.id, limit=5)`).
     - Format a specialized weekly briefing message:
       `📅 *BRIEFING HEBDOMADAIRE TENDERS.TN — LUNDI MATIN*`
       Summary of top priority tenders for the week, deadlines, cautionnements, and direct link to dashboard.
     - Dispatch via `send_whatsapp_message(sub.phone, briefing_text)`.
     - Log in `notification_logs` (channel: `"WHATSAPP_WEEKLY"`).
     - Return execution summary: `{"success": true, "briefings_sent": count, "subscribers_targeted": count}`.
3. **Scheduler & Routes (`app.py`)**:
   - Fix bug line 88: Replace `notifier.dispatch_notifications()` with `notifier.dispatch_alerts(limit=50)`.
   - In `autonomous_scheduler_loop()`:
     - Add check for Monday morning at 08h30 (Tunis time `Africa/Tunis`, weekday == 0, hour == 8, minute >= 30, and not already sent today).
     - When condition triggers: call `notifier.send_weekly_briefing()`.
   - Add testable endpoints:
     - `POST /api/client/weekly-briefing/{sub_id}`: calls `notifier.send_weekly_briefing(subscriber_id=sub_id)`, returns HTTP 200 with result.
     - `POST /api/admin/dispatch-weekly-briefing`: calls `notifier.send_weekly_briefing()`, returns HTTP 200 with result.
4. **Verification**:
   - Run `test_global_e2e.py` and verify `test_08`, `test_10`, `test_20`, `test_21` all PASS.
   - Verify non-regression on existing daily morning briefing and alert dispatching.

## MANDATORY INTEGRITY WARNING
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. An auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

## 2026-10-18T11:04:48Z
You are Worker M4 (Alertes WhatsApp Enrichies & Briefing Hebdomadaire).
Read your instructions in C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m4\DISPATCH.md.
Also read C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md and C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md.

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. An auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Implement:
1. `notifier.py`:
   - Enrich `format_whatsapp_message` to include direct links:
     * Fiche officielle TUNEPS : `🔗 *Fiche officielle TUNEPS :* {tender.url}`
     * Dossier de soumission Tenders.tn : `📂 *Dossier de soumission Tenders.tn :* {app_url}/dashboard?tab=dossiers&tender={bid_id}`
     Make sure the string "Dossier de soumission" and the query param `tab=dossiers` are present.
   - Implement `send_weekly_briefing(self, subscriber_id: Optional[int] = None)`:
     Fetches matched active tenders, formats a weekly priority summary for the week, sends via `send_whatsapp_message`, logs to `notification_logs` with channel `WHATSAPP_WEEKLY`, and returns summary dictionary.
2. `app.py`:
   - Fix line 88 bug: Replace `notifier.dispatch_notifications()` with `notifier.dispatch_alerts(limit=50)`.
   - In `autonomous_scheduler_loop()`: add check for Monday 08h30 Tunis time to trigger `notifier.send_weekly_briefing()`.
   - Add routes:
     `POST /api/client/weekly-briefing/{sub_id}`
     `POST /api/admin/dispatch-weekly-briefing`
     both calling `notifier.send_weekly_briefing` and returning HTTP 200.
3. Run tests: verify `test_08`, `test_10`, `test_20`, `test_21` in `test_global_e2e.py` PASS, and run the entire suite `python test_global_e2e.py` to see the final overall score!
Write your handoff report to C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m4\handoff.md and notify orchestrator_1.
