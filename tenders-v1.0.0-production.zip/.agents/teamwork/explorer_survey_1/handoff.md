# Handoff Report — Explorer Survey 1 (Backend, SQLite WAL, Auth PBKDF2)

## 1. Observation

### 1.1 Technology Stack & Dependencies
- **Runtime & Environment**:
  - Python version: `Python 3.12` on Windows (executable: `C:\Users\Faiez.chakchouk\AppData\Local\Programs\Python\Python312\python.exe`).
  - No Node.js / `package.json` build step; frontend assets are static HTML/JS with Tailwind CSS loaded via CDN script.
- **Dependencies (`requirements.txt`)**:
  - Location: `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\requirements.txt`
  - Core Web: `fastapi>=0.110.0,<1.0.0` (installed: `fastapi 0.143.2`, `starlette 1.8.0`), `uvicorn[standard]>=0.28.0,<1.0.0` (installed: `0.54.0`), `pydantic[email]>=2.6.0,<3.0.0` (installed: `2.14.1`), `jinja2>=3.1.0,<4.0.0` (installed: `3.1.6`), `requests>=2.31.0,<3.0.0`, `urllib3>=2.0.0,<3.0.0`.
  - Document Generation: `python-docx>=1.1.0,<2.0.0` (installed: `1.2.0`), `reportlab>=4.0.0,<5.0.0` (installed: `5.0.1`), `pillow>=10.0.0,<11.0.0` (installed: `13.0.0`).
  - Configuration: `python-dotenv>=1.0.0,<2.0.0` (installed: `1.2.4`).
  - Production: `gunicorn>=21.2.0,<23.0.0`.
  - HTTP client: `httpx` (installed: `0.28.1`).
  - Missing dependency for R2: `openpyxl` is **not installed** (`ModuleNotFoundError: No module named 'openpyxl'`).

### 1.2 Database Architecture & WAL Mode
- **Database File**: `tenders.db` (companion files: `tenders.db-shm`, `tenders.db-wal`).
- **Connection Helper (`database.py:116-123`)**:
  ```python
  def _get_connection(self):
      conn = sqlite3.connect(self.db_path)
      conn.row_factory = sqlite3.Row
      # Mode WAL pour accès concurrent (scheduler thread + requêtes web)
      conn.execute("PRAGMA journal_mode=WAL;")
      conn.execute("PRAGMA busy_timeout=5000;")
      return conn
  ```
- **Direct WAL Mode Verification**:
  - Command: `python -c "import sqlite3; conn = sqlite3.connect('tenders.db'); print(conn.execute('PRAGMA journal_mode;').fetchone()[0])"`
  - Tool Output: `wal`
- **Tables Present in SQLite**:
  `['tenders', 'subscribers', 'sqlite_sequence', 'notification_logs', 'tenders_fts', 'tenders_fts_data', 'tenders_fts_idx', 'tenders_fts_content', 'tenders_fts_docsize', 'tenders_fts_config', 'client_bookmarks', 'submission_dossiers', 'monthly_usage', 'payment_transactions']`.
- **Subscriber & Client Schema (`database.py:184-216`)**:
  - `subscribers` columns:
    `id` (INTEGER PRIMARY KEY), `company_name` (TEXT), `phone` (TEXT), `email` (TEXT), `categories` (TEXT JSON), `governorates` (TEXT JSON), `keywords` (TEXT JSON), `channel` (TEXT), `plan` (TEXT), `is_active` (INTEGER), `created_at` (TEXT), `features` (TEXT JSON), `logo_url` (TEXT), `rne_id` (TEXT), `address` (TEXT), `phone_office` (TEXT), `bank_name` (TEXT), `rib` (TEXT), `monthly_pack_quota` (INTEGER), `password_hash` (TEXT).
- **Dossiers Schema (`database.py:249-265`)**:
  - `submission_dossiers` columns:
    `id` (INTEGER PRIMARY KEY), `subscriber_id` (INTEGER), `tender_id` (INTEGER), `created_at` (TEXT), `files_included` (TEXT JSON), `format_type` (TEXT), `total_price` (REAL), `status` (TEXT), `notes` (TEXT).
  - Existing status in DB: `PREPARATION` (5 rows existing).

### 1.3 PBKDF2 Authentication Details
- **Implementation in `database.py:21-36`**:
  ```python
  def hash_password(password: str) -> str:
      salt = secrets.token_hex(16)
      h = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 100_000)
      return f"{salt}:{h.hex()}"

  def verify_password(password: str, stored_hash: Optional[str]) -> bool:
      if not stored_hash or ":" not in stored_hash:
          return False
      try:
          salt, h = stored_hash.split(":", 1)
          test_h = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 100_000)
          return secrets.compare_digest(h, test_h.hex())
      except Exception:
          return False
  ```
- **Phone Lookup & Normalization (`database.py:712-728`)**:
  Takes last 8 digits (`short_num = clean_digits[-8:]`) and queries:
  `WHERE phone LIKE ? OR phone LIKE ?` with `f"%{short_num}"` and `f"+216{short_num}"`.
- **Credential Verification (`database.py:1014-1037`)**:
  - `verify_subscriber_credentials(phone, password)`: finds subscriber, verifies password with `verify_password`. If `sub.password_hash` is None/empty (unmigrated user), initializes password on first login if length >= 4.
  - `set_subscriber_password(sub_id, password)`: updates `password_hash` with `hash_password(password.strip())`.

### 1.4 Existing API Routes
- **Client Auth & Onboarding**:
  - `POST /api/client/login` (`app.py:572-608`): Authenticates via phone + password, returns subscriber data & stats.
  - `POST /api/subscribe` (`app.py:394-450`): Registers new subscriber. For `plan == "TRIAL"`, sets `is_active=1`, saves PBKDF2 password if supplied, and sends WhatsApp welcome message.
  - `GET /api/client/profile/{sub_id}` (`app.py:610-634`)
  - `PUT /api/client/profile/{sub_id}` (`app.py:636-666`): Updates profile & optionally hashes new password.
  - `POST /api/client/test-alert/{sub_id}` (`app.py:702-752`)
- **Opportunities & Bookmarks**:
  - `GET /api/client/opportunities/{sub_id}` (`app.py:668-674`): Calls `db.get_subscriber_matched_tenders(sub_id, limit=50)`.
  - `GET /api/client/bookmarks/{sub_id}` (`app.py:676-682`)
  - `POST /api/client/bookmark` (`app.py:684-695`)
  - `DELETE /api/client/bookmark/{sub_id}/{tender_id}` (`app.py:697-700`)
  - `GET /api/tenders/search` (`app.py:235-280`): FTS5 search.
  - `GET /api/tenders/{tender_id}` (`app.py:282-315`)
- **Dossiers & Branding**:
  - `GET /api/client/dossiers/{sub_id}` (`app.py:2192-2203`): Calls `db.get_subscriber_dossiers(sub_id)`.
  - `POST /api/client/dossiers/{dossier_id}/status` (`app.py:2205-2226`): Updates dossier status and notes.
  - `GET /api/client/branding/{sub_id}` (`app.py:2228-2246`)
  - `POST /api/client/branding` (`app.py:2248-2264`)
  - `GET /api/client/quota/{sub_id}` (`app.py:2266-2274`)
- **Morning Briefing**:
  - `POST /api/admin/dispatch-morning-briefing` (`app.py:2519-2523`)
  - `POST /api/client/morning-briefing/{sub_id}` (`app.py:2525-2529`)
- **Frontend Serving**:
  - `GET /` (`app.py:540-550`): Serves `public/index.html` (falls back to `templates/index.html`).
  - `GET /dashboard` & `GET /client` (`app.py:754-766`): Serves `public/dashboard.html` (falls back to `templates/dashboard.html`).

### 1.5 Local Execution & Testing Commands
- **Local Server**:
  - `python app.py` (entry point runs `uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)`).
  - Or `python -m uvicorn app:app --host 0.0.0.0 --port 8000`.
- **Testing**:
  - `fastapi.testclient.TestClient` works with installed Python 3.12:
    `python -c "from fastapi.testclient import TestClient; import app; client = TestClient(app.app); print(client.get('/health').json())"`
  - Test suites can be executed via `python -m unittest discover -s . -p "*test*.py"`.
  - Standalone script: `python setup_test_subscribers.py`.

### 1.6 Exact File Paths
- Server Entry Point: `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\app.py`
- Database Layer: `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\database.py`
- Central Config: `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\config.py`
- WhatsApp Gateway: `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\whatsapp_gateway.py`
- Notification Engine: `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\notifier.py`
- Templates:
  - `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\templates\dashboard.html`
  - `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\public\dashboard.html`
  - `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\templates\index.html`
  - `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\public\index.html`
- SQLite Database: `C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\tenders.db`

---

## 2. Logic Chain

1. **Database Concurrency & WAL Mode**:
   - `database.py` sets `PRAGMA journal_mode=WAL;` and `PRAGMA busy_timeout=5000;` on every connection returned by `_get_connection()`.
   - Inspection of `tenders.db` confirmed `journal_mode: wal` with active `.db-shm` and `.db-wal` files.
   - Consequently, background thread jobs (`autonomous_scheduler_loop`) and incoming HTTP requests execute concurrently without database lock collisions.

2. **Authentication Flow (R1)**:
   - Passwords are encrypted with PBKDF2-HMAC-SHA256 (100,000 iterations) using a 16-byte random hex salt (`secrets.token_hex(16)`), formatted as `salt:hex_hash`.
   - The frontend stores subscriber profile in `localStorage.setItem('tenders_client_sub', ...)` upon `POST /api/client/login`.
   - To support R1:
     - Need a new table `password_reset_otps` (or helper methods in `database.py`) storing `(subscriber_id, phone, otp_code, expires_at, used)`.
     - Two new endpoints in `app.py`:
       - `POST /api/client/forgot-password/request`: finds subscriber by phone, generates a 6-digit OTP (valid 10 minutes), records in DB, and dispatches via `send_whatsapp_message(phone, msg)`.
       - `POST /api/client/forgot-password/verify`: validates OTP and phone, updates password via `db.set_subscriber_password(sub.id, new_password)`.
     - In `dashboard.html` (both `templates/` and `public/`): add "Mot de passe oublié ?" modal/form and "Créer un compte d'essai gratuit" tab/toggle calling `POST /api/subscribe`.

3. **Export & Filtering (R2)**:
   - `db.get_subscriber_matched_tenders(subscriber_id)` already pulls all tenders matching the subscriber's sector and region criteria.
   - New endpoint `GET /api/client/opportunities/{sub_id}/export`:
     - Can take `format: str = Query('xlsx')` ('xlsx' or 'csv').
     - Generates CSV (UTF-8 with BOM `utf-8-sig` for Excel compatibility) or `.xlsx`.
     - For `.xlsx`: install `openpyxl` or provide streaming workbook generation.
     - Columns required: N° Avis (`bid_no`), Acheteur (`buyer_name`), Objet (`title_fr`/`title_ar`), Région (`governorate`/`execution_place`), Date limite (`deadline_date`), Cautionnement (`guarantee_type`).
   - In `tab-opportunities`: add instant search input filtering the rendered DOM cards by keyword / `bid_no`, plus export button.
   - In `tab-dossiers`: add a filter bar pills (`TOUS`, `GENERE`, `DEPOSE_TUNEPS`, `RETENU`, `NON_RETENU`) to filter the cards rendered by `loadSubscriberDossiers()`.

4. **Compliance & Legal Pages (R3)**:
   - `render_client_dashboard` and `render_landing_page` serve static files prioritizing `public/` over `templates/`.
   - New routes needed in `app.py`:
     - `GET /cgu` -> serves `cgu.html` (HTTP 200).
     - `GET /confidentialite` -> serves `confidentialite.html` (HTTP 200).
   - Footers in `templates/index.html`, `public/index.html`, `templates/dashboard.html`, `public/dashboard.html` need links to `/cgu` and `/confidentialite`.

5. **WhatsApp Alerts & Monday Briefing (R4)**:
   - `notifier.py:format_whatsapp_message` generates alerts. Direct links to TUNEPS (`{tender.url}`) and submission pack / dashboard (`{BASE_URL}/dashboard`) can be enriched cleanly.
   - `autonomous_scheduler_loop` in `app.py:78-112` already checks `tunis_now.hour == briefing_target_hour`.
   - Monday 08:30 briefing requirement:
     - Check `tunis_now.weekday() == 0` (Monday) and `tunis_now.hour == 8 and tunis_now.minute == 30` (or >= 30).
     - Add endpoint `POST /api/admin/dispatch-weekly-briefing` or test trigger endpoint to verify on demand.

---

## 3. Caveats

- **No Caveats** regarding the core backend architecture, WAL mode, PBKDF2 authentication, or file locations.
- **Dependency Notice**: `openpyxl` is not present in `requirements.txt` or current environment. Implementers must either `pip install openpyxl` (and add it to `requirements.txt`) or build `.xlsx` using a lightweight fallback/CSV.
- **HTML Synchronization**: Any changes made to `templates/*.html` must be synchronized to `public/*.html`, because `app.py` checks `public/` first.

---

## 4. Conclusion

The Tenders.tn backend is a production-ready, cleanly organized FastAPI application with SQLite in full WAL mode. Authentication relies securely on PBKDF2-HMAC-SHA256 with 100,000 iterations and salt hashing. All 4 commercial improvement tracks (R1, R2, R3, R4) have clear extension points in `app.py`, `database.py`, `notifier.py`, `templates/`, and `public/`. Local testing is directly executable via Python's standard `unittest` and `fastapi.testclient.TestClient`.

---

## 5. Verification Method

To independently verify the observations and conclusions in this report:

1. **Verify SQLite WAL Mode**:
   ```powershell
   python -c "import sqlite3; conn = sqlite3.connect('tenders.db'); print('journal_mode:', conn.execute('PRAGMA journal_mode;').fetchone()[0])"
   ```
   *Expected output*: `journal_mode: wal`.

2. **Verify PBKDF2 Password Hashing**:
   ```powershell
   python -c "import database; h = database.hash_password('testpass'); print('Valid format:', ':' in h and len(h.split(':')[0]) == 32); print('Verified:', database.verify_password('testpass', h))"
   ```
   *Expected output*: `Valid format: True`, `Verified: True`.

3. **Verify FastAPI Server & Health Route**:
   ```powershell
   python -c "from fastapi.testclient import TestClient; import app; client = TestClient(app.app); res = client.get('/health'); print(res.status_code, res.json()['status'])"
   ```
   *Expected output*: `200 healthy`.

4. **Verify Existing Subscribers & Database Schema**:
   ```powershell
   python -c "import database; db = database.TenderDatabase(); subs = db.get_active_subscribers(); print(f'Active subscribers: {len(subs)}'); [print(s.company_name, s.phone, s.plan) for s in subs]"
   ```

5. **Verify Missing `openpyxl` Caveat**:
   ```powershell
   python -c "import openpyxl"
   ```
   *Expected output*: `ModuleNotFoundError: No module named 'openpyxl'`.
