# Rapport d'Exploration & Analyse Technique (Survey 3)
**Domaines :** WhatsApp Service, Scheduler / Cron, Export Excel / CSV, Matching Abonnés, Intégrité Génération Documentaire  
**Date :** 2026-10-18  
**Auteur :** Explorer Survey 3  
**Destinataire :** orchestrator_1 (`ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9`)

---

## 1. Observation

### 1.1 Passerelle WhatsApp & Templates de Messages
- **Architecture de passerelle :**
  - Fichier : `whatsapp_gateway.py` (lignes 140-163). La fonction principale `send_whatsapp_message(phone: str, message: str) -> bool` implémente un routage résilient :
    1. Tentative prioritaire via **Meta Cloud API** (`send_meta_whatsapp_message`, lignes 47-105). Endpoint officiel : `https://graph.facebook.com/v21.0/{phone_id}/messages`. Tente d'abord un envoi de texte direct (`type: "text"`), avec basculement automatique sur le template officiel `hello_world` en cas de fermeture de la fenêtre de session 24h (lignes 84-99).
    2. En cas d'échec ou d'indisponibilité de Meta, basculement automatique vers **Green-API** (`send_green_api_message`, lignes 107-134) via `https://api.green-api.com/waInstance{instance_id}/sendMessage/{token}`.
    3. Si les deux passerelles échouent, le système logue `Passerelles indisponibles. Message simulé vers {phone}` et retourne `False` (lignes 161-162).
  - Nettoyage des numéros : `clean_phone_number(phone: str)` dans `whatsapp_gateway.py:40-45` supprime les espaces, tirets et le `+`, puis préfixe systématiquement par `216` pour la Tunisie.
- **Configuration & Secrets :**
  - Fichier : `whatsapp_config.json` (lignes 1-8) et `config.py` (lignes 24-33). Variables : `WHATSAPP_PROVIDER`, `META_PHONE_NUMBER_ID`, `META_ACCESS_TOKEN`, `GREEN_API_INSTANCE_ID`, `GREEN_API_TOKEN`, `META_VERIFY_TOKEN`.
- **Webhooks entrants :**
  - Fichier : `app.py`.
    - `GET /api/webhook/meta` (lignes 312-326) : validation du challenge Meta (`hub.challenge`).
    - `POST /api/webhook/meta` (lignes 328-366) : réception des messages entrants et réponse instantanée par `BotResponder(db=db).search_and_format_reply(text_body, channel="WHATSAPP")`.
    - `POST /api/webhook/green-api` (lignes 368-392) : traitement des webhooks Green-API.
- **Formatage des messages d'alerte :**
  - Fichier : `notifier.py:67-108` (`format_whatsapp_message`).
    - Le message contient : Secteur, Acheteur, Région, Objet, Date limite dépôt, Tags, Conditions de soumission TUNEPS-3 (Critère, Cautionnement, Cahier des charges, Lieu, Ouverture des plis, Mode de dépôt), Synthèse IA, et lien vers l'avis TUNEPS `tender.url`.
    - **Manque identifié (R4) :** Aucun lien direct vers le Dossier de soumission / classeur client Tenders.tn n'est inclus dans les alertes générées.

### 1.2 Authentification, Gestion des Mots de Passe & Récupération OTP (R1)
- **Hachage & Sécurité :**
  - Fichier : `database.py:21-37`.
    ```python
    def hash_password(password: str) -> str:
        salt = secrets.token_hex(16)
        h = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 100_000)
        return f"{salt}:{h.hex()}"
    ```
    Hachage conforme PBKDF2-HMAC-SHA256 avec 100 000 itérations et sel aléatoire de 16 octets.
  - Vérification par `verify_password(password, stored_hash)` via `secrets.compare_digest` à temps constant.
  - Mise à jour sécurisée : `db.set_subscriber_password(sub_id, password)` (`database.py:1004-1012`).
  - Validation connexion : `db.verify_subscriber_credentials(phone, password)` (`database.py:1014-1035`).
- **Absence actuelle d'OTP & Récupération :**
  - Aucun endpoint `/api/client/forgot-password/request` ni `/api/client/forgot-password/verify` n'existe dans `app.py`.
  - Aucune table de stockage des codes OTP n'existe dans SQLite (`database.py`).
  - Dans l'interface `templates/dashboard.html` (lignes 68-115), le formulaire de connexion ne possède ni lien "Mot de passe oublié ?" ni bascule vers la création d'un compte d'essai gratuit.

### 1.3 Moteur de Planification en Arrière-plan (Scheduler / Cron)
- **Démon autonome permanent :**
  - Fichier : `app.py:69-132` (`autonomous_scheduler_loop`). Lancé comme daemon thread au démarrage de FastAPI (`@app.on_event("startup")` ligne 129).
  - Intervalle de veille : `SYNC_INTERVAL_MINUTES` (30 minutes par défaut, configurable via `.env`).
  - **Anomalie critique détectée dans `app.py:88` :**
    ```python
    # Ligne 88 de app.py :
    notifier.dispatch_notifications()
    ```
    Or, dans `notifier.py`, la classe `TenderNotifier` ne définit pas `dispatch_notifications()`, mais `dispatch_alerts(limit=50)` (ligne 155). Cela génère une exception `AttributeError: 'TenderNotifier' object has no attribute 'dispatch_notifications'` lorsque de nouveaux marchés sont insérés.
- **Briefing Matinal quotidien (actuel) :**
  - Déclenché à 08:00 (UTC+1 Tunis) chaque jour : `notifier.send_morning_briefing(sub.id)` (`app.py:91-105` et `notifier.py:193-260`).
  - Endpoints manuels existants : `POST /api/admin/dispatch-morning-briefing` (`app.py:2519`) et `POST /api/client/morning-briefing/{sub_id}` (`app.py:2525`).
- **Briefing Hebdomadaire du Lundi 08h30 (R4) :**
  - **Manque identifié :** Actuellement, aucun briefing hebdomadaire spécialisé pour le lundi matin à 08h30 n'est planifié ni codé, et aucun endpoint de déclenchement d'essai dédié n'est exposé.

### 1.4 Algorithme de Matching des Opportunités
- **Identification des abonnés actifs :**
  - `database.py:631` : `SELECT * FROM subscribers WHERE is_active = 1`.
  - Deux profils actifs actuellement configurés en base :
    - ID 1 : `ADVANCIA TRAINING PRO`, `+21628177888`, catégories `["ETUDES_CONSEIL", "AUTRES"]`.
    - ID 2 : `TUNISIE PC / IT SOLUTIONS`, `+21698111222`, catégories `["IT_TELECOM", "FOURNITURES_SERVICES"]`.
- **Logique de correspondance (Matching) :**
  - Deux implémentations complémentaires :
    1. **Moteur Notifier (`notifier.py:41-65`) :**
       - Catégorie : Vrai si `"ALL" in sub.categories` ou `tender.category in sub.categories`.
       - Région : Vrai si `"ALL" in sub.governorates` ou si le gouvernorat du marché correspond ou contient `"national"`.
       - Mots-clés : Vrai si `sub.keywords` est vide, ou si au moins un mot-clé est présent dans le titre FR/AR ou les tags.
    2. **Moteur Dashboard SQL (`database.py:1136-1215`, `get_subscriber_matched_tenders`) :**
       - Filtre les marchés non expirés (`t.deadline_date >= datetime.now()`).
       - Filtre par catégorie SQLite `IN (...)` et gouvernorat.
       - Calcule dynamiquement le compte à rebours d'urgence (`CRITICAL`, `URGENT`, `MEDIUM`, `RELAXED`).
       - Associe le statut des favoris/bookmarks.

### 1.5 Capacités d'Export Excel / CSV
- **Inspection des bibliothèques installées :**
  - Exécution de `pip list` dans l'environnement Python du projet :
    - `csv` : inclus en natif dans la bibliothèque standard Python.
    - `openpyxl` : **non installé**.
    - `xlsxwriter` : **non installé**.
    - `pandas` : **non installé**.
  - Test d'installation dry-run : `pip install --dry-run openpyxl` a confirmé que `openpyxl-3.1.5` et sa dépendance `et-xmlfile-2.0.0` sont téléchargeables et installables sans conflit.
- **Endpoints d'export actuels :**
  - Aucun endpoint d'export Excel ni CSV n'existe actuellement dans `app.py`.
- **Spécifications requises (R2) :**
  - Colonnes requises : N° Avis, Acheteur, Objet, Région, Date limite, Cautionnement.
  - Encodage UTF-8 obligatoire (UTF-8 avec BOM `utf-8-sig` pour le CSV afin de garantir l'ouverture parfaite sous Microsoft Excel Windows sans altération des accents ni des caractères arabes).

### 1.6 Génération Documentaire & Contraintes d'Intégrité
- **Documents générés :**
  - `pdf_generator.py` (719 lignes) et `docx_generator.py` (750 lignes) génèrent 5 documents officiels conformes au Décret n° 2014-1039 :
    1. Acte d'engagement solennel (`generate_engagement_letter_*`).
    2. Demande de cautionnement bancaire provisoire/définitif (`generate_bank_guarantee_*`).
    3. Mémoire technique d'exécution synthétique (`generate_technical_proposal_*`).
    4. Offre financière & Bordereau des Prix Unitaires BPU/DQE (`generate_commercial_bpu_*`).
    5. Demande d'éclaircissements / questions HAICOP (`generate_clarification_*`).
  - Pack complet d'archivage : `/api/tenders/{tender_id}/submission-pack.zip` (`app.py:1948`) assemble ces documents dans une arborescence normée à 5 dossiers (`01_Offre_Administrative`, `02_Offre_Technique`, `03_Offre_Financiere`, `04_Juridique_HAICOP`, `05_Strategie_Notation`).
- **Contraintes d'intégrité à préserver :**
  - Format strict **1 seule page A4** par document (marges de 0.5 pouce / 36 pt, paddings de cellules réduits, styles typographiques compacts).
  - Emplacement bloc signature électronique réservé aux certificats TunTrust / ANCE.
  - Contrôle et décompte des quotas mensuels SaaS (`db.check_and_record_usage(sub.id)` dans `app.py:1975`).
  - Base de données SQLite maintenue en mode WAL (`PRAGMA journal_mode=WAL;`).

### 1.7 Synchronisation des Templates UI
- Inspection des dossiers :
  - `templates/` contient 7 fichiers HTML (`admin.html`, `dashboard.html`, `index.html`, etc.).
  - `public/` contient exactement les 7 mêmes fichiers HTML avec des tailles identiques.
  - **Règle absolue :** Toute modification apportée à `dashboard.html` ou `index.html` doit être dupliquée à l'identique entre `templates/` et `public/`.

---

## 2. Logic Chain

### Étape 1 : Chaîne logique pour R1 (Récupération OTP WhatsApp & Onboarding Essai)
1. *Observation 1.1 & 1.2* : `whatsapp_gateway.py:send_whatsapp_message` route de façon éprouvée vers Meta Cloud API et Green-API avec nettoyage du numéro de téléphone. `database.py:hash_password` et `set_subscriber_password` gèrent le stockage PBKDF2 sécurisé.
2. *Déduction* : L'implémentation de la réinitialisation de mot de passe par OTP nécessite :
   - Une table SQLite `password_reset_otps` (champs : `id`, `subscriber_id`, `phone`, `otp_code`, `expires_at`, `is_used`, `created_at`) avec index sur `phone` et `otp_code`.
   - L'endpoint `POST /api/client/forgot-password/request` :
     - Valide le numéro et recherche l'abonné via `db.get_subscriber_by_phone(phone)`.
     - Génère un code aléatoire à 6 chiffres via `f"{secrets.randbelow(900000) + 100000:06d}"`.
     - Enregistre le code avec une expiration de 10 minutes (`datetime.now() + timedelta(minutes=10)`).
     - Expédie le message formaté via `send_whatsapp_message(sub.phone, message)`.
   - L'endpoint `POST /api/client/forgot-password/verify` :
     - Vérifie la validité du code (non expiré, non utilisé).
     - Si valide, marque `is_used = 1` et applique `db.set_subscriber_password(sub.id, new_password)`.
   - L'interface `dashboard.html` :
     - Ajout dans `auth-section` d'un bouton "Mot de passe oublié ?" ouvrant un formulaire modal ou un panneau de saisie OTP.
     - Ajout d'une bascule/onglet "Connexion" vs "Essai Gratuit 7 jours" appelant directement `POST /api/subscribe` avec `plan: "TRIAL"` pour supprimer toute friction d'inscription.

### Étape 2 : Chaîne logique pour R2 (Export Excel/CSV & Filtrage "Mes Dossiers")
1. *Observation 1.4 & 1.5* : `database.py:get_subscriber_matched_tenders` extrait déjà l'ensemble des marchés qualifiés pour un abonné donné. `openpyxl` peut être installé via pip pour générer des fichiers `.xlsx` natifs, tandis que le module standard `csv` avec `utf-8-sig` produit des fichiers `.csv` ouvrables instantanément dans Excel.
2. *Déduction* : L'implémentation de l'export nécessite :
   - L'installation d'`openpyxl` et son ajout dans `requirements.txt`.
   - L'endpoint `GET /api/client/opportunities/{sub_id}/export` acceptant un paramètre `format=xlsx` (défaut) ou `format=csv` (avec alternative d'accès direct `/api/client/opportunities/{sub_id}/export.xlsx` et `export.csv`).
   - Génération des colonnes requises : `N° Avis`, `Acheteur`, `Objet`, `Région`, `Date limite`, `Cautionnement`, complétées de `Secteur` et `Lien TUNEPS`.
   - Ajout dans l'onglet des opportunités de `dashboard.html` des boutons de téléchargement direct (`.xlsx` et `.csv`) et d'un champ d'input pour le filtrage instantané par mot-clé et numéro d'avis (filtrage côté client en JavaScript sans appel réseau).
3. *Observation 1.3 & 1.7* : Dans l'onglet "Mes Dossiers" (`#tab-dossiers`), les dossiers sont rendus par `loadSubscriberDossiers()` depuis `/api/client/dossiers/{sub_id}` avec le champ `submission_status` (`GENERE`, `DEPOSE_TUNEPS`, `RETENU`, `NON_RETENU`).
4. *Déduction* : L'ajout d'une barre de filtres (`TOUS`, `GENERE`, `DEPOSE_TUNEPS`, `RETENU`, `NON_RETENU`) dans `#tab-dossiers` avec bascule de classe active et masquage/affichage instantané des cartes DOM répond exactement à l'exigence R2 sans rechargement de page.

### Étape 3 : Chaîne logique pour R4 (Alertes WhatsApp Enrichies & Briefing Hebdomadaire)
1. *Observation 1.1* : `notifier.py:format_whatsapp_message` génère l'alerte individuelle mais omet le lien vers le dossier de soumission.
2. *Déduction* : L'enrichissement consiste à injecter dans le message WhatsApp :
   ```
   🔗 *Fiche officielle TUNEPS :* {tender.url}
   📂 *Dossier de soumission Tenders.tn :* {app_url}/dashboard?tab=dossiers&tender={tender.ep_bid_master_id}
   ```
3. *Observation 1.3* : `app.py:88` contient un bug de nommage (`notifier.dispatch_notifications()` au lieu de `notifier.dispatch_alerts()`), et la boucle de fond ne gère actuellement que le briefing quotidien de 08:00.
4. *Déduction* : Pour satisfaire R4 :
   - Corriger la ligne 88 de `app.py` pour appeler `notifier.dispatch_alerts()`.
   - Créer la méthode `send_weekly_briefing(self, subscriber_id: Optional[int] = None)` dans `notifier.py`, ciblant les marchés clés de la semaine à venir.
   - Ajouter dans `autonomous_scheduler_loop()` le déclenchement du lundi à 08h30 :
     `if tunis_now.weekday() == 0 and tunis_now.hour == 8 and tunis_now.minute >= 30 and last_weekly_briefing_date != today_str:`
   - Exposer l'endpoint d'essai testable `POST /api/client/weekly-briefing/{sub_id}` et `POST /api/admin/dispatch-weekly-briefing`.

---

## 3. Caveats
1. **Accès réseau Meta Cloud API :** En environnement de développement local ou de test automatisé isolé sans jetons Meta réels renseignés dans `.env`, `send_whatsapp_message` bascule sur Green-API puis retourne une simulation gracieuse (`False` avec log d'avertissement). Les tests automatisés doivent vérifier que l'appel d'expédition est déclenché avec le payload attendu sans bloquer le flux HTTP.
2. **Installation d'openpyxl :** Bien que `pip install --dry-run openpyxl` ait confirmé l'absence d'obstacles, la mise à jour de `requirements.txt` et l'installation de la dépendance dans l'environnement virtuel doivent être réalisées lors de la phase d'implémentation.
3. **Persistance WAL SQLite :** En cas d'accès très intensif entre le thread de fond et les workers web, la commande `PRAGMA busy_timeout = 5000;` déjà présente garantit l'absence de verrous `database is locked`, à condition de toujours fermer les connexions SQLite dans un bloc `with`.

---

## 4. Conclusion
L'architecture actuelle de Tenders.tn est solide, modulaire et prête à recevoir les améliorations demandées :
1. **Chantier R1 (Sécurité & Onboarding) :**
   - Implémenter les endpoints `/api/client/forgot-password/request` et `/api/client/forgot-password/verify` adossés à une table SQLite `password_reset_otps` et au hachage PBKDF2 existant.
   - Mettre à jour `dashboard.html` (synchronisé dans `templates/` et `public/`) avec le flux "Mot de passe oublié ?" et l'onglet "Essai gratuit direct".
2. **Chantier R2 (Outils Métier & Export) :**
   - Installer `openpyxl>=3.1.0` et l'ajouter à `requirements.txt`.
   - Créer `/api/client/opportunities/{sub_id}/export` (supportant `.xlsx` et `.csv` UTF-8 avec BOM).
   - Intégrer les boutons d'export et le filtrage instantané (recherche plein texte dans l'onglet opportunités et barre de statut `TOUS`, `GENERE`, `DEPOSE_TUNEPS`, `RETENU`, `NON_RETENU` dans l'onglet dossiers).
3. **Chantier R4 (Alertes & Briefing Hebdomadaire) :**
   - Corriger l'appel `notifier.dispatch_alerts()` à la ligne 88 de `app.py`.
   - Enrichir le gabarit d'alerte WhatsApp avec le lien direct vers le dossier de soumission.
   - Ajouter `send_weekly_briefing()` dans `notifier.py`, son ordonnancement le lundi à 08h30 dans `autonomous_scheduler_loop()`, et l'endpoint testable `POST /api/client/weekly-briefing/{sub_id}`.
4. **Intégrité Documentaire :**
   - Les générateurs PDF et DOCX existants respectent rigoureusement le Décret n° 2014-1039 et la contrainte de 1 page A4 ; aucune régression ne doit être introduite sur leurs gabarits ou leurs signatures.

---

## 5. Verification Method

Pour vérifier de manière indépendante et reproductible les constats et futures implémentations :

### A. Vérification de l'environnement et des dépendances
```powershell
python -c "import openpyxl" # Attendu actuellement : ModuleNotFoundError (à installer)
python -c "import csv, io, sqlite3, hashlib, secrets; print('Core modules OK')"
python -c "import sqlite3; conn = sqlite3.connect('tenders.db'); print('WAL mode:', conn.execute('PRAGMA journal_mode;').fetchone()[0])"
```

### B. Vérification du bug de scheduler dans `app.py`
```powershell
python -c "import app, notifier; print('Has dispatch_alerts:', hasattr(app.notifier, 'dispatch_alerts')); print('Has dispatch_notifications:', hasattr(app.notifier, 'dispatch_notifications'))"
# Résultat attendu : dispatch_alerts = True, dispatch_notifications = False (confirme le bug ligne 88)
```

### C. Vérification de la cohérence des templates
```powershell
# Comparaison bit à bit entre templates/ et public/
python -c "
import filecmp, os
for f in os.listdir('templates'):
    t_path = os.path.join('templates', f)
    p_path = os.path.join('public', f)
    if os.path.isfile(t_path):
        same = filecmp.cmp(t_path, p_path, shallow=False)
        print(f'{f}:', 'IN SYNC' if same else 'DESYNCHRONIZED')
"
```

### D. Condition d'invalidation
Le diagnostic sera invalidé si :
1. Une table `password_reset_otps` existait déjà sous un autre nom non détecté.
2. Une fonction `dispatch_notifications` existait dynamiquement dans `TenderNotifier` via `__getattr__` (vérifié négatif : `TenderNotifier` est une classe Python standard).
