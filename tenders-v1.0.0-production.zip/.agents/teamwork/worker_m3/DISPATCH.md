# DISPATCH — Worker M3 (Conformité Réglementaire & Juridique Tunisie)

## Identity
- Archetype: teamwork_preview_worker
- Role: Regulatory & Legal Compliance Worker
- Working directory: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m3
- Parent: orchestrator_1 (ecc1ebb1-d09d-4119-a6c9-4ec8ab115ce9)

## Context & Inputs
- Requirement source: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md (§R3)
- Project architecture & contracts: C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md (§M3)
- Existing tests: `test_18_regulatory_cgu_endpoint`, `test_19_regulatory_confidentialite_endpoint`, `test_24_footer_legal_links_in_all_templates` in `test_global_e2e.py`.

## Scope & File Ownership
- `templates/cgu.html` AND `public/cgu.html` (new files, 100% synchronized)
- `templates/confidentialite.html` AND `public/confidentialite.html` (new files, 100% synchronized)
- `app.py` (add routes `@app.get("/cgu")` and `@app.get("/confidentialite")`)
- `templates/index.html` AND `public/index.html` (footer links to `/cgu` and `/confidentialite`)
- `templates/dashboard.html` AND `public/dashboard.html` (footer with links to `/cgu` and `/confidentialite`)

## Implementation Requirements
1. **Legal Templates (`templates/cgu.html`, `public/cgu.html`)**:
   - Clean, professional Tailwind UI adhering to Tenders.tn corporate design (dark slate theme, Inter font, header navigation returning to `/` or `/dashboard`).
   - Comprehensive legal text in French adhering to:
     - Décret n° 2014-1039 portant réglementation des marchés publics en Tunisie.
     - Loi n° 2000-83 relative aux échanges et au commerce électronique.
     - Conditions d'utilisation des passerelles de paiement bancaires tunisiennes agréées par la Banque Centrale de Tunisie (Konnect, Flouci, GIM-TEL / Monétique Tunisie) : tarification en Dinars Tunisiens (TND), droit de rétractation, modalités d'abonnement SaaS, gestion des litiges devant les juridictions tunisiennes compétentes (Tribunal de Première Instance de Tunis).
2. **Privacy Policy Templates (`templates/confidentialite.html`, `public/confidentialite.html`)**:
   - Conforme à la Loi organique n° 2004-63 du 27 juillet 2004 portant sur la protection des données à caractère personnel (Instance Nationale de Protection des Données Personnelles - INPDP).
   - Déclarations relatives à la collecte des numéros WhatsApp, consentement pour les alertes instantanées via Meta Cloud API / WhatsApp Gateway, droits d'accès, de rectification et d'opposition du client abonné, sécurisation des mots de passe (PBKDF2-HMAC-SHA256 100 000 itérations).
3. **FastAPI Routes (`app.py`)**:
   - `GET /cgu`: serves `public/cgu.html` (fallback `templates/cgu.html`) with `Content-Type: text/html; charset=utf-8` and HTTP 200.
   - `GET /confidentialite`: serves `public/confidentialite.html` (fallback `templates/confidentialite.html`) with `Content-Type: text/html; charset=utf-8` and HTTP 200.
4. **Footer Links Synchronization**:
   - In `index.html` (both `templates/` and `public/`): ensure footer contains visible links:
     `<a href="/cgu" ...>Conditions Générales d'Utilisation</a>` and `<a href="/confidentialite" ...>Politique de Confidentialité</a>`.
   - In `dashboard.html` (both `templates/` and `public/`): add a clean corporate footer containing the same links and copyright notice before `</body>`.
5. **Verification**:
   - Run `test_global_e2e.py` and verify `test_18`, `test_19`, `test_24` PASS.
   - Verify 100% binary parity between `templates/` and `public/` across all HTML files.

## MANDATORY INTEGRITY WARNING
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. An auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.


## 2026-10-18T10:55:09Z
You are Worker M3 (Conformité Réglementaire & Juridique Tunisie).
Read your instructions in C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m3\DISPATCH.md.
Also read C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\ORIGINAL_REQUEST.md and C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\PROJECT.md.

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. An auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Implement:
1. `templates/cgu.html` and `public/cgu.html`: Full professional legal terms compliant with Tunisian law (Décret 2014-1039, Loi 2000-83, Konnect/Flouci/GIM-TEL payment specs, jurisdiction Tunis).
2. `templates/confidentialite.html` and `public/confidentialite.html`: Full professional privacy policy compliant with Tunisian law (Loi organique 2004-63 INPDP, WhatsApp Cloud API data rules).
3. `app.py`: Routes `@app.get("/cgu")` and `@app.get("/confidentialite")` returning HTTP 200 with HTML content.
4. Footers: Ensure links to `/cgu` and `/confidentialite` are present in both `templates/index.html` & `public/index.html` AND `templates/dashboard.html` & `public/dashboard.html`.
5. Ensure 100% binary parity across all files in `templates/` vs `public/`.
6. Run tests: verify `test_18_regulatory_cgu_endpoint`, `test_19_regulatory_confidentialite_endpoint`, `test_24_footer_legal_links_in_all_templates`, and `test_04_html_templates_mirror_parity` in `test_global_e2e.py` PASS.
Write your handoff report to C:\Users\Faiez.chakchouk\.gemini\antigravity\scratch\marches-publics-tunisie\.agents\teamwork\worker_m3\handoff.md and notify orchestrator_1.
